import { Component, OnInit } from '@angular/core';

import { KeyNumber } from "../key-value";
import { KeyString } from "../key-value";
import { KeyBool } from "../key-value"
import { KeyStringArray } from "../key-value";
import { KeyNumberArray } from "../key-value"
import { KeyObject } from "../key-value";
import { LoadJsonService } from '../load-json.service';
import { LocalBreak } from "../template_definitions";
import { NgbModal, ModalDismissReasons } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public config: KeyObject;
  public existingTemplates = <string[]>[];
  closeResult = ''; 

  constructor(private LoadJsonService: LoadJsonService, private modalService: NgbModal) {
    // let url = "http://127.0.0.1:8000/config"
    let url = "/assets/config.json"
      this.LoadJsonService.getConfig(url).subscribe(data => {
      this.config = data;
      console.log(this.config)
      for(let i = 3; i < this.config.value.length; i++) {
        this.existingTemplates.push(this.config.value[i].key)
      }
    })
    }
  
    open(content) {
      this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        this.closeResult = `Network Created Successfuly`;
      }, (reason) => {
        this.closeResult = ``;
      });
    }
  
    private getDismissReason(reason: any): string {
      if (reason === ModalDismissReasons.ESC) {
        return 'by pressing ESC';
      } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
        return 'by clicking on a backdrop';
      } else {
        return `with: ${reason}`;
      }
    }
  
  ngOnInit(): void {
  }
}