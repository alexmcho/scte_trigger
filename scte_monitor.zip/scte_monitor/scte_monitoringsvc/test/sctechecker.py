import threefive
import json

# cuetypes
CUE_IN = "IN"
CUE_OUT = "OUT"

# scte-35 command types
Splice_Null = 0x00
Splice_Schedule = 0x04
Splice_Insert = 0x05
Time_Signal = 0x06
Bandwith_Reservation = 0x07
Private_Command = 0xff

# Command list for easy retreaval
Command_List = [0x00, 0x04, 0x05, 0x06, 0x07, 0xff]


def get_nested_item(nested_dictionary, key):
    '''
    Recursive function that returns the value of the given key if found, else None
    '''
    try:
        return nested_dictionary[key]
    except KeyError as e:
        for _key, _value in nested_dictionary.items():
            if type(_value) is dict:
                return get_nested_item(_value, key)

        return None


class ScteChecker:
    '''
    ScteChecker implements decoding of base64 scte and comparison tools
    '''

    # commandtype has the command that the program will be using for further checking !(DEFAULTS TO SPLICE NULL)
    commandtype = Splice_Null

    # undropped contains id's from verify_undropped method
    undropped = dict()

    # template contains the object that has the values to compare
    template = dict()

    # --- Contructor ---
    def __init__(self, templatefile, commandtype):
        try:
            self.load_template(templatefile)
            self.set_commandtype(commandtype)
        except EnvironmentError as e:
            # if errors starting app occurred then log
            open(file='./log.txt', mode='a').write(str(e) +
                                                   "File: " + templatefile + "\n")
            raise e
        except NotImplementedError as e:
            open(file='./log.txt', mode='a').write(str(e) +
                                                   "Command: " + hex(commandtype) + "\n")
            raise e

    # --- Functions ---
    def get_commandtype(self):
        '''
        Gets the command type for further template comparison
        '''
        return self.commandtype

    def set_commandtype(self, commandtype):
        '''
        Sets the command type for further template comparison
        '''
        found = False
        for i in range(len(Command_List)):
            if commandtype == Command_List[i]:
                found = True
                break

        if found:
            self.commandtype = commandtype
        else:
            raise NotImplementedError(
                "Specified scte-35 command type is not valid\n")

    def load_template(self, templatefile):
        '''
        Loads the template file and converts into object for further comparison
        '''
        try:
            self.template = json.loads(open(templatefile, 'r').read())
        except Exception as e:
            print(e)
            raise EnvironmentError(
                "Error reading or parsing the template file\n")

    def clear_undropped(self):
        '''
        Clears the undropped dictionary
        Useful when done with the file. (Remember to get_undropped() first)
        '''
        self.undropped.clear()

    def get_undropped(self):
        '''
        Return the dictionary containing the id for non dropped triggers
        '''
        return self.undropped

    def verify_dropped(self, uuid, lastValue):
        '''
        Looks for uuid in the dictionary if exist deletes the key if DELETE is present on last index (del[key])
        '''
        if uuid not in self.undropped:
            self.undropped[uuid] = lastValue
        else:
            try:
                del self.undropped[uuid]
            except KeyError as identifier:
                print(identifier)

    def verify_deviation(self, line, cuetype=None):
        '''
        Function verify_deviation is a custom log parser and checker.
        The cuetype argument can be omited. 
        If the cuetype is passed it will only run the template check if logData[0] is equal to the cue type. (CUE_IN, CUE_OUT)
        This function does multiple things:
            - Call to template_check() = checks if the log deviates from a template then it return true
            - Call to verify_dropped() = submits the log id to the undropped dictionary
        '''
        deviates = False

        # fullLog includes the timestamp and the logged data (size=2)
        # ["20200610160000", "IN:COOKHD-6216.dfw.1080:5116f552-f9d6-4b5f-980f-153d404a8679:/DBAAAAAAAAAAP/wBQb/UI5s1gAqAihDVUVJAHTtZ3+9DBlESVNDMTgyNTE4XzAwM18wM181NzVBLTA0EQEBzge5ug==:PTS-5646478550"]
        fullLog = line.split(sep=' ')

        # logData containes the log portion split on the colon (size=5)
        # ["IN", "COOKHD-6216.dfw.1080", "5116f552-f9d6-4b5f-980f-153d404a8679", "/DBAAAAAAAAAAP/wBQb/UI5s1gAqAihDVUVJAHTtZ3+9DBlESVNDMTgyNTE4XzAwM18wM181NzVBLTA0EQEBzge5ug==", "PTS-5646478550"]
        logData = fullLog[1].split(sep=':')

        # Call to template_check to compare the data on the template and the current scte
        if cuetype is None:
            scte = threefive.cue.Cue(logData[3]).get()
            deviates = self.template_check(scte)
        else:
            if logData[0] == cuetype:
                scte = threefive.cue.Cue(logData[3]).get()
                deviates = self.template_check(scte)

        # Verify the dropped status
        self.verify_dropped(logData[2], logData[-1])

        return deviates

    def template_check(self, scte):
        '''
        Checks if the log deviates from a template then it return true
        '''

        if self.commandtype == Splice_Insert and scte["info_section"]["splice_command_type"] == Splice_Insert:
            return self.check_insert(scte)
        
        # Return true for all the scte cues that have Splice_Null under the info_section
        elif self.commandtype == Splice_Null and scte["info_section"]["splice_command_type"] == Splice_Null:
            return True
        
        # Else statement will always return a false as long as the scte does not match 
        # the command type set by the user or does not match the info_section
        else:
            return False

    # --- Compare logic ---
    def check_insert(self, scte):
        '''
        Compare when command is Splice_Insert = 0x05 with the arguments on template
        '''
        # Validate the template command type with the class command type
        if self.commandtype == self.template["splice_command_type"]:
            # The line below is to print a log file with all scte that follow the aforemention rule
            # open('splice-insert-log.txt', 'a').write(json.dumps(scte,indent = 2) + "\n")

            '''
            Start comparison
            '''
            deviates = False
            template_command = self.template.get("command")
            sctecommand = scte.get("command")
            if template_command is not None and sctecommand is not None:
                if type(scte["command"].get("splice_event_id")) is int:
                    for key in template_command:

                        # The proccess below executes when duration_flag key is encountered
                        if key in sctecommand and key == "duration_flag":
                            if sctecommand[key] == template_command[key] and template_command[key] == True:
                                # if duration_flag is true then validate the duration portion [auto_return, reserved, duration]
                                dur_res = template_command.get("duration_reserved")
                                if dur_res is not None:
                                    if dur_res["break_auto_return"] != sctecommand["break_auto_return"]:
                                        deviates = True
                                        break
                                    
                                    # Check duration
                                    duration = dur_res.get("duration")
                                    if duration is not None:
                                        if len(duration) > 1:
                                            if sctecommand["break_duration"] < duration[0] or sctecommand["break_duration"] > duration[1]:
                                                deviates = True
                                                break
                                        elif sctecommand["break_duration"] != duration[0]:
                                            deviates = True
                                            break
                            else:
                                if sctecommand[key] != template_command[key]:
                                    deviates = True
                                    break
                        elif key in sctecommand:
                            if sctecommand[key] != template_command[key]:
                                deviates = True
                                break
                else:
                    deviates = True
                return deviates
            else:
                # If template command section dictionary is empty or scte command section dictionary is empty, 
                # there are no fields to compare therefore deviation is defaulted to False
                return deviates
        else:
            # Return false since the template command type does not match the class commandtype
            print("Not appropiate template")
            return False